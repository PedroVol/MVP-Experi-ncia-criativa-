from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from datetime import datetime
import random

app = Flask(__name__, template_folder="templates")
app.secret_key = "Feito_pelo_PedroeAsTongas"  

login_manager = LoginManager(app)
login_manager.login_view = "login"

class User(UserMixin):
    def __init__(self, id, name, email, role):
        self.id = str(id)
        self.name = name
        self.email = email
        self.role = role
    @property
    def is_admin(self):
        return self.role == "admin"

USERS = {
    "1": User(1, "Admin", "admin@example.com", "admin"),
    "2": User(2, "Voluntária Ana", "ana@example.com", "voluntario"),
}

@login_manager.user_loader
def load_user(user_id):
    return USERS.get(str(user_id))

VOLUNTARIOS = [
    {"id": 1, "nome": "Ana Souza", "rfid": "04A1B2C3D4", "ativo": True},
    {"id": 2, "nome": "Carlos Lima", "rfid": None, "ativo": True},
    {"id": 3, "nome": "Bianca Melo", "rfid": "09FBC22D", "ativo": False},
]

REGISTROS_PONTO = [
    {"id": 10, "nome": "Ana Souza", "tipo": "Entrada", "origem": "ESP", "horario": "08:02"},
    {"id": 11, "nome": "Carlos Lima", "tipo": "Entrada", "origem": "WEB", "horario": "08:10"},
    {"id": 12, "nome": "Ana Souza", "tipo": "Saída", "origem": "ESP", "horario": "12:03"},
]

IOT_CFG = {
    "host": "test.mosquitto.org",
    "port": 1883,
    "tls": False,
    "client_id": "server-001",
    "username": "",
    "topic_ponto": "esp/+/ponto",
}

DISPOSITIVOS = [
    {"device_id": "ESP001", "status": "online", "ultima_conexao": "agora"},
    {"device_id": "ESP002", "status": "offline", "ultima_conexao": "há 2h"},
]

MAPEAMENTOS = [{"rfid": "04A1B2C3D4", "nome": "Ana Souza"}]

MQTT_STATUS = "offline"
MQTT_INFO = ""
CONSOLE = []

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "")
        user = USERS["1"] if "admin" in email else USERS["2"]
        login_user(user)
        flash("Login efetuado com sucesso!", "success")
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Sessão encerrada.", "success")
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    kpis = {
        "voluntarios_ativos": sum(1 for v in VOLUNTARIOS if v["ativo"]),
        "presencas_hoje": len(REGISTROS_PONTO),
        "dispositivos_online": sum(1 for d in DISPOSITIVOS if d["status"] == "online"),
        "ultimo_evento": f'{REGISTROS_PONTO[-1]["nome"]} • {REGISTROS_PONTO[-1]["tipo"]}' if REGISTROS_PONTO else "-",
    }
    eventos = [{"tipo": r["tipo"], "nome": r["nome"], "hora": r["horario"], "origem": r["origem"]} for r in REGISTROS_PONTO]
    return render_template("dashboard.html", kpis=kpis, eventos=eventos, mqtt_status=MQTT_STATUS, mqtt_info=MQTT_INFO)

@app.route("/ponto")
@login_required
def ponto():
    return render_template("ponto.html", registros=REGISTROS_PONTO)

@app.route("/ponto/registrar/<tipo>")
@login_required
def ponto_registrar(tipo):
    if tipo not in ("entrada","saida","Entrada","Saída"):
        flash("Tipo inválido.", "error")
        return redirect(url_for("ponto"))
    REGISTROS_PONTO.append({
        "id": random.randint(100,999),
        "nome": current_user.name,
        "tipo": "Entrada" if tipo.lower()=="entrada" else "Saída",
        "origem": "WEB",
        "horario": datetime.now().strftime("%H:%M")
    })
    flash("Registro adicionado.", "success")
    return redirect(url_for("ponto"))

@app.route("/ponto/<int:id>/corrigir")
@login_required
def ponto_corrigir(id):
    flash(f"Correção simulada para o registro {id}.", "success")
    return redirect(url_for("ponto"))

@app.route("/voluntarios")
@login_required
def voluntarios():
    return render_template("voluntarios_list.html", voluntarios=VOLUNTARIOS)

@app.route("/voluntarios/novo", methods=["GET","POST"])
@login_required
def voluntarios_novo():
    if request.method == "POST":
        novo = {
            "id": max([v["id"] for v in VOLUNTARIOS]+[0])+1,
            "nome": request.form.get("nome"),
            "doc": request.form.get("doc"),
            "email": request.form.get("email"),
            "telefone": request.form.get("telefone"),
            "rfid": request.form.get("rfid") or None,
            "ativo": True if request.form.get("ativo")=="on" else False,
        }
        VOLUNTARIOS.append(novo)
        flash("Voluntário criado.", "success")
        return redirect(url_for("voluntarios"))
    return render_template("voluntario_form.html", voluntario=None)

@app.route("/voluntarios/<int:id>/editar", methods=["GET","POST"])
@login_required
def voluntarios_editar(id):
    v = next((x for x in VOLUNTARIOS if x["id"]==id), None)
    if not v:
        flash("Voluntário não encontrado.", "error")
        return redirect(url_for("voluntarios"))
    if request.method == "POST":
        v.update({
            "nome": request.form.get("nome"),
            "doc": request.form.get("doc"),
            "email": request.form.get("email"),
            "telefone": request.form.get("telefone"),
            "rfid": request.form.get("rfid") or None,
            "ativo": True if request.form.get("ativo")=="on" else False,
        })
        flash("Voluntário atualizado.", "success")
        return redirect(url_for("voluntarios"))
    return render_template("voluntario_form.html", voluntario=v)

@app.route("/voluntarios/<int:id>/excluir")
@login_required
def voluntarios_excluir(id):
    global VOLUNTARIOS
    VOLUNTARIOS = [x for x in VOLUNTARIOS if x["id"] != id]
    flash("Voluntário excluído.", "success")
    return redirect(url_for("voluntarios"))

@app.route("/usuarios")
@login_required
def usuarios():
    usuarios = [{"id": u.id, "nome": u.name, "email": u.email, "papel": u.role} for u in USERS.values()]
    return render_template("usuarios_list.html", usuarios=usuarios)

@app.route("/usuarios/novo", methods=["GET","POST"])
@login_required
def usuarios_novo():
    if request.method == "POST":
        flash("Mock: criação de usuário realizada.", "success")
        return redirect(url_for("usuarios"))
    return render_template("usuario_form.html", usuario=None)

@app.route("/usuarios/<int:id>/editar", methods=["GET","POST"])
@login_required
def usuarios_editar(id):
    u = USERS.get(str(id))
    usuario = {"id": u.id, "nome": u.name, "email": u.email, "papel": u.role} if u else None
    if request.method == "POST":
        flash("Mock: atualização de usuário realizada.", "success")
        return redirect(url_for("usuarios"))
    return render_template("usuario_form.html", usuario=usuario)

@app.route("/iot", methods=["GET"])
@login_required
def iot():
    return render_template("iot.html",
                           cfg=IOT_CFG,
                           mqtt_status=MQTT_STATUS,
                           console="\n".join(CONSOLE[-50:]),
                           mapeamentos=MAPEAMENTOS,
                           dispositivos=DISPOSITIVOS)

@app.route("/iot/salvar", methods=["POST"])
@login_required
def iot_salvar():
    IOT_CFG["host"] = request.form.get("host", IOT_CFG["host"])
    IOT_CFG["port"] = int(request.form.get("port", IOT_CFG["port"]))
    IOT_CFG["tls"] = True if request.form.get("tls")=="on" else False
    IOT_CFG["client_id"] = request.form.get("client_id", "")
    IOT_CFG["username"] = request.form.get("username", "")
    IOT_CFG["topic_ponto"] = request.form.get("topic_ponto", IOT_CFG["topic_ponto"])
    flash("Configurações salvas.", "success")
    return redirect(url_for("iot"))

@app.route("/iot/testar", methods=["POST"])
@login_required
def iot_testar():
    global MQTT_STATUS, MQTT_INFO
    MQTT_STATUS = "online"
    MQTT_INFO = "Conexão simulada OK (mock)."
    flash("Teste de conexão MQTT concluído (mock).", "success")
    CONSOLE.append('{"deviceId":"ESP001","rfid":"04A1B2C3D4","event":"tap","ts":%d}' % int(datetime.now().timestamp()))
    return redirect(url_for("dashboard"))

@app.route("/relatorios")
@login_required
def relatorios():
    linhas = [
        {"nome":"Ana Souza", "horas":"04:00", "atrasos":0},
        {"nome":"Carlos Lima", "horas":"03:30", "atrasos":1},
    ]
    return render_template("relatorios.html", linhas=linhas)

@app.route("/relatorios/export/<fmt>")
@login_required
def relatorios_export(fmt):
    flash(f"Exportação {fmt.upper()} gerada (mock).", "success")
    return redirect(url_for("relatorios"))

@app.route("/suporte")
@login_required
def suporte():
    ava_url = "https://ava.exemplo.br/formulario" # não posso esquecer de trocar esse link antes de enviar pro andrey
    return render_template("suporte.html", ava_url=ava_url)

if __name__ == "__main__":
    app.run(debug=True)