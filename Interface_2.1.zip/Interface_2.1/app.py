from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_login import (
    LoginManager, UserMixin, login_user, login_required,
    logout_user, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os, json, random
from datetime import datetime, date

# --- Configuração base ---
app = Flask(__name__, template_folder="templates")
app.secret_key = "pedro_eas_gurias"  # troque em produção

login_manager = LoginManager(app)
login_manager.login_view = "login"

# --- Persistência simples em JSON para contas registradas ---
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)
USERS_JSON = os.path.join(DATA_DIR, "users.json")

def _load_registered():
    if not os.path.exists(USERS_JSON):
        return []
    try:
        with open(USERS_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def _save_registered(items):
    with open(USERS_JSON, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)

REGISTERED = _load_registered()

SCHEMA_VERSION = 3  # nova versão com ficha completa

def _migrate_user(u: dict) -> dict:
    # versão
    if "version" not in u:
        u["version"] = 1
    # bloco ficha
    u.setdefault("ficha_voluntariado", {})
    f = u["ficha_voluntariado"]
    # campos mínimos (deixe default vazio)
    defaults = {
        "unidade": "", "nascimento": "", "local_nasc": "", "rg": "", "cpf": "",
        "estado_civil": "", "conjuge": "", "pai": "", "mae": "",
        "endereco": {"logradouro":"", "numero":"", "cep":"", "bairro":"", "cidade":"", "uf":""},
        "tel_resid": "", "celular": "", "religiao": "",
        "escolaridade": "", "local_trabalho": "", "tel_trabalho": "",
        "ocupacoes": [], "ocup_outro": "",
        "trat_medico": "Nao", "trat_para": "",
        "transporte": "", "como_soube": "",
        "exp_voluntario": "Nao", "exp_onde": "", "grupo_vol": "",
        "contribuicao": "", "hab_musical": "Nao", "hab_musical_qual": "",
        "aux_alimentacao": "Nao",
        "disp": {},  # ex.: {"segunda":{"ini":"08:00","fim":"12:00"}, ...}
        "cidade_ass": "", "data_ass": "", "aceite_termos": False
    }
    # aplica defaults
    for k,v in defaults.items():
        f.setdefault(k, v if not isinstance(v, dict) else json.loads(json.dumps(v)))
    u["version"] = SCHEMA_VERSION
    return u

# aplica migração a todos
REGISTERED = [_migrate_user(u) for u in REGISTERED]


def _find_registered_by_email(email):
    email = (email or "").strip().lower()
    for it in REGISTERED:
        if it.get("email", "").lower() == email:
            return it
    return None

# --- Seed do ADMIN (email/senha fixos) ---
ADMIN_EMAIL = "admin@gmail.com"
ADMIN_PASSWORD = "admin"
ADMIN_NAME = "Admin"
ADMIN_ID = 1  

if not any(u.get("email","").lower() == ADMIN_EMAIL for u in REGISTERED):
    REGISTERED.append({
        "id": ADMIN_ID,
        "name": ADMIN_NAME,
        "email": ADMIN_EMAIL,
        "role": "admin",
        "password_hash": generate_password_hash(ADMIN_PASSWORD),
        "created_at": datetime.now().isoformat()
    })
    _save_registered(REGISTERED)

# --- Classe User ---
class User(UserMixin):
    def __init__(self, id, name, email, role, password_hash=None):
        self.id = str(id)
        self.name = name
        self.email = email
        self.role = role
        self.password_hash = password_hash

    @property
    def is_admin(self):
        return self.role == "admin"


# --- Mock inicial + merge dos registrados ---
USERS = {
    "1": User(1, "Voluntária Ana", "ana@example.com", "voluntario"),
}

for it in REGISTERED:
    uid = it.get("id")
    if uid is None:
        continue
    USERS[str(uid)] = User(
        uid,
        it.get("name"),
        it.get("email"),
        it.get("role", "voluntario"),
        it.get("password_hash")
    )

def _get_birthday_from_reg(reg: dict) -> str:
    """Tenta achar a data de nascimento do usuário em vários lugares."""
    if not reg:
        return ""
    ficha = reg.get("ficha_voluntariado", {}) or {}
    return (
        ficha.get("nascimento", "") or    # novo cadastro
        reg.get("nascimento", "")         # legado (se algum usuário antigo salvou no topo)
    ).strip()

@login_manager.user_loader
def load_user(user_id):
    return USERS.get(str(user_id))

@app.route("/voluntarios/<int:id>/editar", methods=["GET", "POST"])
@login_required
def voluntarios_editar(id):
    # procura o voluntário pelo ID
    v = next((x for x in VOLUNTARIOS if x["id"] == id), None)
    if not v:
        flash("Voluntário não encontrado.", "error")
        return redirect(url_for("voluntarios"))

    # se for POST, atualiza o voluntário
    if request.method == "POST":
        v.update({
            "nome": request.form.get("nome"),
            "rfid": request.form.get("rfid") or None,
            "ativo": True if request.form.get("ativo") == "on" else False,
        })
        flash("Voluntário atualizado.", "success")
        return redirect(url_for("voluntarios"))

    # se for GET, abre o formulário com dados do voluntário
    return render_template("voluntario_form.html", voluntario=v)

@app.route("/voluntarios/<int:id>/excluir")
@login_required
def voluntarios_excluir(id):
    global VOLUNTARIOS
    # remove pelo id
    VOLUNTARIOS = [x for x in VOLUNTARIOS if x["id"] != id]
    flash("Voluntário excluído.", "success")
    return redirect(url_for("voluntarios"))

# --- Mock de domínio ---
VOLUNTARIOS = [
    {"id": 1, "nome": "Ana Souza", "rfid": "04A1B2C3D4", "ativo": True},
    {"id": 2, "nome": "Carlos Lima", "rfid": None, "ativo": True},
]
REGISTROS_PONTO = [
    {"id": 10, "nome": "Ana Souza", "tipo": "Entrada", "origem": "ESP", "horario": "08:02"},
    {"id": 11, "nome": "Carlos Lima", "tipo": "Entrada", "origem": "WEB", "horario": "08:10"},
]
IOT_CFG = {"host": "test.mosquitto.org", "port": 1883}
MQTT_STATUS = "offline"


# --- Middleware: protege tudo que não for login/register/static ---
@login_manager.unauthorized_handler
def unauthorized():
    flash("Faça login para continuar.", "error")
    return redirect(url_for("login"))

@app.before_request
def require_login_for_everything():
    public_endpoints = {"login", "register", "static"}
    if request.endpoint is None:
        return
    if request.endpoint.split(".")[0] not in public_endpoints and not current_user.is_authenticated:
        return redirect(url_for("login"))

def _validate_registration(form):
    required = ["name","email","password","password2","cpf","nascimento","end_logradouro","end_numero","end_cep","end_bairro","end_cidade","end_uf","unidade"]
    missing = [k for k in required if not (form.get(k) or "").strip()]
    if missing:
        return False, "Campos obrigatórios ausentes: " + ", ".join(missing)
    if form.get("password") != form.get("password2"):
        return False, "As senhas não conferem."
    if "@" not in form.get("email",""):
        return False, "E-mail inválido."
    if not form.get("aceite_termos"):
        return False, "É necessário aceitar os termos."
    # disponibilidade: limite até 22:00 (opcional, apenas valida se preenchido)
    for d in ["segunda","terca","quarta","quinta","sexta","sabado","domingo"]:
        ini, fim = form.get(f"disp_{d}_ini",""), form.get(f"disp_{d}_fim","")
        for t in [ini,fim]:
            if t and t > "22:00":
                return False, f"Em {d.title()}, o horário não pode passar de 22:00."
    return True, ""

def _is_birthday(date_str: str) -> bool:
    try:
        d = datetime.strptime(date_str.strip(), "%Y-%m-%d").date()
        today = date.today()
        print("DEBUG: nascimento recebido =", date_str, "-> comparando com", today)
        return d.month == today.month and d.day == today.day
    except Exception as e:
        print("Erro _is_birthday:", e)
        return False

# --- Rotas públicas ---
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        ok, err = _validate_registration(request.form)
        if not ok:
            flash(err, "error")
            return render_template("register.html")

        name  = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        role  = request.form.get("role", "voluntario")

        # data de nascimento pode ter nomes diferentes no form
        nascimento = (request.form.get("nascimento")
                      or request.form.get("data_nasc")
                      or "").strip()

        if _find_registered_by_email(email):
            flash("Já existe uma conta com este e-mail.", "error")
            return render_template("register.html")

        # disponibilidade (gera dict só com os preenchidos)
        disp = {}
        for d in ["segunda","terca","quarta","quinta","sexta","sabado","domingo"]:
            ini = (request.form.get(f"disp_{d}_ini", "") or "").strip()
            fim = (request.form.get(f"disp_{d}_fim", "") or "").strip()
            if ini or fim:
                disp[d] = {"ini": ini, "fim": fim}

        new_id = max([int(u.id) for u in USERS.values()] + [100]) + 1
        item = {
            "id": new_id,
            "name": name,
            "email": email,
            "role": role,
            "password_hash": generate_password_hash(password),
            "created_at": datetime.now().isoformat(),
            "version": SCHEMA_VERSION,
            "ficha_voluntariado": {
                "unidade": request.form.get("unidade", ""),
                "nascimento": nascimento,  # usa a variável capturada
                "local_nasc": request.form.get("local_nasc", ""),
                "rg": request.form.get("rg", ""),
                "cpf": request.form.get("cpf", ""),
                "estado_civil": request.form.get("estado_civil", ""),
                "conjuge": request.form.get("conjuge", ""),
                "pai": request.form.get("pai", ""),
                "mae": request.form.get("mae", ""),
                "endereco": {
                    "logradouro": request.form.get("end_logradouro", ""),
                    "numero": request.form.get("end_numero", ""),
                    "cep": request.form.get("end_cep", ""),
                    "bairro": request.form.get("end_bairro", ""),
                    "cidade": request.form.get("end_cidade", ""),
                    "uf": (request.form.get("end_uf", "") or "").upper(),
                },
                "tel_resid": request.form.get("tel_resid", ""),
                "celular": request.form.get("celular", ""),
                "religiao": request.form.get("religiao", ""),
                "escolaridade": request.form.get("escolaridade", ""),
                "local_trabalho": request.form.get("local_trabalho", ""),
                "tel_trabalho": request.form.get("tel_trabalho", ""),
                "ocupacoes": request.form.getlist("ocup[]"),
                "ocup_outro": request.form.get("ocup_outro", ""),
                "trat_medico": request.form.get("trat_medico", "Nao"),
                "trat_para": request.form.get("trat_para", ""),
                "transporte": request.form.get("transporte", ""),
                "como_soube": request.form.get("como_soube", ""),
                "exp_voluntario": request.form.get("exp_voluntario", "Nao"),
                "exp_onde": request.form.get("exp_onde", ""),
                "grupo_vol": request.form.get("grupo_vol", ""),
                "contribuicao": request.form.get("contribuicao", ""),
                "hab_musical": request.form.get("hab_musical", "Nao"),
                "hab_musical_qual": request.form.get("hab_musical_qual", ""),
                "aux_alimentacao": request.form.get("aux_alimentacao", "Nao"),
                "disp": disp,
                "cidade_ass": request.form.get("cidade_ass", ""),
                "data_ass": request.form.get("data_ass", ""),
                "aceite_termos": bool(request.form.get("aceite_termos")),
            },
        }

        REGISTERED.append(item)
        _save_registered(REGISTERED)

        USERS[str(new_id)] = User(new_id, name, email, role, item["password_hash"])
        login_user(USERS[str(new_id)])
        flash("Conta criada e login efetuado!", "success")

        # tela de feliz aniversário (YYYY-MM-DD)
        if nascimento and _is_birthday(nascimento):
            return render_template("feliz_aniversario.html", nome=name)

        return redirect(url_for("dashboard"))

    return render_template("register.html")

@app.route("/feliz-aniversario")
@login_required
def feliz_aniversario():
    nome = request.args.get("nome", current_user.name)
    return render_template("feliz_aniversario.html", nome=nome)

def _get_registered_by_email(email: str):
    return _find_registered_by_email(email)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password", "")

        reg = _find_registered_by_email(email)
        if not reg:
            flash("Conta não encontrada. Cadastre-se primeiro.", "error")
            return render_template("login.html")

        if not check_password_hash(reg.get("password_hash", "") or "", password):
            flash("Credenciais inválidas.", "error")
            return render_template("login.html")

        u = USERS.get(str(reg["id"]))
        if not u:
            flash("Erro interno: usuário não encontrado na sessão.", "error")
            return render_template("login.html")

        login_user(u)
        flash("Login efetuado com sucesso!", "success")

        # aniversário no login
        ficha = reg.get("ficha_voluntariado", {}) or {}
        nascimento = (ficha.get("nascimento", "") or reg.get("nascimento", "")).strip()
        print("[LOGIN] nascimento:", nascimento, "| hoje:", date.today())  # debug opcional

        if nascimento and _is_birthday(nascimento):
            # mostra só uma vez por dia
            if session.get("birthday_seen") != str(date.today()):
                session["birthday_seen"] = str(date.today())
                return render_template("feliz_aniversario.html", nome=u.name)

        return redirect(url_for("dashboard"))

    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Sessão encerrada.", "success")
    return redirect(url_for("login"))


# --- Rotas autenticadas ---
@app.route("/")
@login_required
def dashboard():
    kpis = {
        "voluntarios_ativos": sum(1 for v in VOLUNTARIOS if v["ativo"]),
        "presencas_hoje": len(REGISTROS_PONTO),
        "dispositivos_online": 0
    }
    return render_template("dashboard.html", kpis=kpis)


@app.route("/usuarios")
@login_required
def usuarios():
    if not current_user.is_admin:
        flash("Apenas administradores podem ver usuários.", "error")
        return redirect(url_for("dashboard"))
    usuarios = [{"id": u.id, "nome": u.name, "email": u.email, "papel": u.role} for u in USERS.values()]
    return render_template("usuarios_list.html", usuarios=usuarios)

def _get_registered_by_id(uid: int):
    for it in REGISTERED:
        if it.get("id") == uid:
            return it
    return None

@app.route("/usuarios/<int:id>/ficha", methods=["GET", "POST"])
@login_required
def usuarios_editar_ficha(id):
    if not current_user.is_admin:
        flash("Apenas administradores podem editar a ficha dos usuários.", "error")
        return redirect(url_for("usuarios"))

    reg = _get_registered_by_id(int(id))
    u = USERS.get(str(id))
    if not reg or not u:
        flash("Usuário não encontrado.", "error")
        return redirect(url_for("usuarios"))

    # garante estrutura da ficha
    ficha = reg.setdefault("ficha_voluntariado", {})
    ficha.setdefault("endereco", {})
    ficha.setdefault("disp", {})

    if request.method == "POST":
        # unidade e dados pessoais
        ficha["unidade"]     = request.form.get("unidade","")
        ficha["nascimento"]  = request.form.get("nascimento","")
        ficha["local_nasc"]  = request.form.get("local_nasc","")
        ficha["rg"]          = request.form.get("rg","")
        ficha["cpf"]         = request.form.get("cpf","")
        ficha["estado_civil"]= request.form.get("estado_civil","")
        ficha["conjuge"]     = request.form.get("conjuge","")
        ficha["pai"]         = request.form.get("pai","")
        ficha["mae"]         = request.form.get("mae","")

        # endereço
        ficha["endereco"]["logradouro"] = request.form.get("end_logradouro","")
        ficha["endereco"]["numero"]     = request.form.get("end_numero","")
        ficha["endereco"]["cep"]        = request.form.get("end_cep","")
        ficha["endereco"]["bairro"]     = request.form.get("end_bairro","")
        ficha["endereco"]["cidade"]     = request.form.get("end_cidade","")
        ficha["endereco"]["uf"]         = (request.form.get("end_uf","") or "").upper()

        # contatos e trabalho
        ficha["tel_resid"]   = request.form.get("tel_resid","")
        ficha["celular"]     = request.form.get("celular","")
        ficha["religiao"]    = request.form.get("religiao","")
        ficha["escolaridade"]= request.form.get("escolaridade","")
        ficha["local_trabalho"] = request.form.get("local_trabalho","")
        ficha["tel_trabalho"]   = request.form.get("tel_trabalho","")

        # ocupações e saúde
        ficha["ocupacoes"]   = request.form.getlist("ocup[]")
        ficha["ocup_outro"]  = request.form.get("ocup_outro","")
        ficha["trat_medico"] = request.form.get("trat_medico","Nao")
        ficha["trat_para"]   = request.form.get("trat_para","")

        # extras
        ficha["transporte"]  = request.form.get("transporte","")
        ficha["como_soube"]  = request.form.get("como_soube","")
        ficha["exp_voluntario"] = request.form.get("exp_voluntario","Nao")
        ficha["exp_onde"]    = request.form.get("exp_onde","")
        ficha["grupo_vol"]   = request.form.get("grupo_vol","")
        ficha["contribuicao"]= request.form.get("contribuicao","")
        ficha["hab_musical"] = request.form.get("hab_musical","Nao")
        ficha["hab_musical_qual"] = request.form.get("hab_musical_qual","")
        ficha["aux_alimentacao"] = request.form.get("aux_alimentacao","Nao")

        # disponibilidade
        disp = {}
        for d in ["segunda","terca","quarta","quinta","sexta","sabado","domingo"]:
            ini = request.form.get(f"disp_{d}_ini","").strip()
            fim = request.form.get(f"disp_{d}_fim","").strip()
            if ini or fim:
                disp[d] = {"ini": ini, "fim": fim}
        ficha["disp"] = disp

        # assinatura
        ficha["cidade_ass"]  = request.form.get("cidade_ass","")
        ficha["data_ass"]    = request.form.get("data_ass","")
        ficha["aceite_termos"]= bool(request.form.get("aceite_termos"))

        _save_registered(REGISTERED)
        flash("Ficha atualizada.", "success")
        return redirect(url_for("usuarios_ver", id=id))

    # GET -> renderiza formulário com dados
    return render_template("usuario_ficha_form.html", usuario=u, ficha=ficha)

def _get_registered_by_id(uid: int):
    for it in REGISTERED:
        if it.get("id") == uid:
            return it
    return None

@app.route("/usuarios/<int:id>")
@login_required
def usuarios_ver(id):
    if not current_user.is_admin:
        flash("Apenas administradores podem ver os detalhes de usuários.", "error")
        return redirect(url_for("usuarios"))

    u = USERS.get(str(id))
    reg = _get_registered_by_id(int(id))  # contém ficha_voluntariado
    if not u or not reg:
        flash("Usuário não encontrado.", "error")
        return redirect(url_for("usuarios"))

    ficha = reg.get("ficha_voluntariado", {})
    return render_template("usuario_detalhe.html", usuario=u, ficha=ficha, reg=reg)

@app.route("/usuarios/novo", methods=["GET", "POST"])
@login_required
def usuarios_novo():
    if not current_user.is_admin:
        flash("Apenas administradores podem criar usuários.", "error")
        return redirect(url_for("usuarios"))

    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        papel = request.form.get("papel", "voluntario")
        senha = request.form.get("senha", "")

        if not nome or not email:
            flash("Preencha nome e e-mail.", "error")
            return render_template("usuario_form.html", usuario=None)

        for it in REGISTERED:
            if it.get("email", "").lower() == email:
                flash("Já existe um usuário com este e-mail.", "error")
                return render_template("usuario_form.html", usuario=None)

        new_id = max([int(u.id) for u in USERS.values()] + [100]) + 1
        item = {
            "id": new_id,
            "name": nome,
            "email": email,
            "role": papel,
            "password_hash": generate_password_hash(senha) if senha else None,
            "created_at": datetime.now().isoformat()
        }

        REGISTERED.append(item)
        _save_registered(REGISTERED)
        USERS[str(new_id)] = User(new_id, nome, email, papel, item["password_hash"])
        flash("Usuário criado.", "success")
        return redirect(url_for("usuarios"))

    return render_template("usuario_form.html", usuario=None)

@app.route("/usuarios/<int:id>/editar", methods=["GET", "POST"])
@login_required
def usuarios_editar(id):
    if not current_user.is_admin:
        flash("Apenas administradores podem editar usuários.", "error")
        return redirect(url_for("usuarios"))

    u = USERS.get(str(id))
    if not u:
        flash("Usuário não encontrado.", "error")
        return redirect(url_for("usuarios"))

    if request.method == "POST":
        nome  = (request.form.get("nome")  or "").strip()
        email = (request.form.get("email") or "").strip().lower()
        papel = (request.form.get("papel") or "voluntario").strip()
        senha = (request.form.get("senha") or "")

        if not nome or not email:
            flash("Preencha nome e e-mail.", "error")
            return render_template("usuario_form.html", usuario={"id": u.id, "nome": u.name, "email": u.email, "papel": u.role})

        # impedir e-mails duplicados
        for it in REGISTERED:
            if it.get("email","").lower() == email and it.get("id") != int(u.id):
                flash("Já existe um usuário com este e-mail.", "error")
                return render_template("usuario_form.html", usuario={"id": u.id, "nome": u.name, "email": u.email, "papel": u.role})

        # aplica alterações no objeto da sessão
        u.name, u.email, u.role = nome, email, papel
        if senha:
            u.password_hash = generate_password_hash(senha)

        # reflete no JSON persistido
        for it in REGISTERED:
            if it.get("id") == int(u.id):
                it["name"]  = nome
                it["email"] = email
                it["role"]  = papel
                if senha:
                    it["password_hash"] = u.password_hash
                break

        _save_registered(REGISTERED)
        flash("Usuário atualizado.", "success")
        return redirect(url_for("usuarios"))

    # GET → carrega formulário
    usuario = {"id": u.id, "nome": u.name, "email": u.email, "papel": u.role}
    return render_template("usuario_form.html", usuario=usuario)

def _count_admins():
    return sum(1 for it in REGISTERED if it.get("role") == "admin")

@app.route("/usuarios/<int:id>/excluir")
@login_required
def usuarios_excluir(id):
    if not current_user.is_admin:
        flash("Apenas administradores podem excluir usuários.", "error")
        return redirect(url_for("usuarios"))

    u = USERS.get(str(id))
    if not u:
        flash("Usuário não encontrado.", "error")
        return redirect(url_for("usuarios"))

    # não permitir excluir a si mesmo
    if str(current_user.id) == str(u.id):
        flash("Você não pode excluir a si mesmo.", "error")
        return redirect(url_for("usuarios"))

    # impedir excluir o último admin
    if u.role == "admin" and _count_admins() <= 1:
        flash("Não é possível excluir o único administrador do sistema.", "error")
        return redirect(url_for("usuarios"))

    # remove do JSON persistido
    global REGISTERED
    REGISTERED = [it for it in REGISTERED if it.get("id") != int(u.id)]
    _save_registered(REGISTERED)

    # remove do dicionário de sessão
    if str(u.id) in USERS:
        del USERS[str(u.id)]

    flash("Usuário excluído.", "success")
    return redirect(url_for("usuarios"))

# --- Outras rotas autenticadas ---
@app.route("/ponto")
@login_required
def ponto():
    return render_template("ponto.html", registros=REGISTROS_PONTO)

@app.route("/ponto/registrar/<tipo>")
@login_required
def ponto_registrar(tipo):
    REGISTROS_PONTO.append({
        "id": random.randint(100, 999),
        "nome": current_user.name,
        "tipo": "Entrada" if tipo.lower() == "entrada" else "Saída",
        "origem": "WEB",
        "horario": datetime.now().strftime("%H:%M")
    })
    flash("Registro adicionado.", "success")
    return redirect(url_for("ponto"))

@app.route("/voluntarios")
@login_required
def voluntarios():
    return render_template("voluntarios_list.html", voluntarios=VOLUNTARIOS)

@app.route("/voluntarios/novo", methods=["GET", "POST"])
@login_required
def voluntarios_novo():
    if request.method == "POST":
        novo = {
            "id": max([v["id"] for v in VOLUNTARIOS] + [0]) + 1,
            "nome": request.form.get("nome"),
            "rfid": request.form.get("rfid") or None,
            "ativo": True if request.form.get("ativo") == "on" else False,
        }
        VOLUNTARIOS.append(novo)
        flash("Voluntário criado.", "success")
        return redirect(url_for("voluntarios"))
    return render_template("voluntario_form.html", voluntario=None)

@app.route("/iot")
@login_required
def iot():
    return render_template("iot.html", cfg=IOT_CFG, mqtt_status=MQTT_STATUS)

@app.route("/relatorios")
@login_required
def relatorios():
    linhas = [{"nome": "Ana Souza", "horas": "04:00"}, {"nome": "Carlos Lima", "horas": "03:30"}]
    return render_template("relatorios.html", linhas=linhas)

@app.route("/suporte")
@login_required
def suporte():
    return render_template("suporte.html", ava_url="https://www.pucpr.br/ava/")

if __name__ == "__main__":
    app.run(debug=True)
