from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import (
    LoginManager, UserMixin, login_user, login_required,
    logout_user, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os, json, random

# --- Configuração base ---
app = Flask(__name__, template_folder="templates")
app.secret_key = "pedro_eas_gurias"  # troque em produção

login_manager = LoginManager(app)
login_manager.login_view = "login"

# --- Persistência simples em JSON para contas registradas ---
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)
USERS_JSON = os.path.join(DATA_DIR, "users.json")

def _load_registered():
    if not os.path.exists(USERS_JSON):
        return []
    try:
        with open(USERS_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def _save_registered(items):
    with open(USERS_JSON, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)

REGISTERED = _load_registered()

def _find_registered_by_email(email):
    email = (email or "").strip().lower()
    for it in REGISTERED:
        if it.get("email", "").lower() == email:
            return it
    return None

# --- Seed do ADMIN (email/senha fixos) ---
ADMIN_EMAIL = "admin@gmail.com"
ADMIN_PASSWORD = "admin"
ADMIN_NAME = "Admin"
ADMIN_ID = 1  

if not any(u.get("email","").lower() == ADMIN_EMAIL for u in REGISTERED):
    REGISTERED.append({
        "id": ADMIN_ID,
        "name": ADMIN_NAME,
        "email": ADMIN_EMAIL,
        "role": "admin",
        "password_hash": generate_password_hash(ADMIN_PASSWORD),
        "created_at": datetime.now().isoformat()
    })
    _save_registered(REGISTERED)

# --- Classe User ---
class User(UserMixin):
    def __init__(self, id, name, email, role, password_hash=None):
        self.id = str(id)
        self.name = name
        self.email = email
        self.role = role
        self.password_hash = password_hash

    @property
    def is_admin(self):
        return self.role == "admin"


# --- Mock inicial + merge dos registrados ---
USERS = {
    "1": User(1, "Voluntária Ana", "ana@example.com", "voluntario"),
}

for it in REGISTERED:
    uid = it.get("id")
    if uid is None:
        continue
    USERS[str(uid)] = User(
        uid,
        it.get("name"),
        it.get("email"),
        it.get("role", "voluntario"),
        it.get("password_hash")
    )

@login_manager.user_loader
def load_user(user_id):
    return USERS.get(str(user_id))

@app.route("/voluntarios/<int:id>/editar", methods=["GET", "POST"])
@login_required
def voluntarios_editar(id):
    # procura o voluntário pelo ID
    v = next((x for x in VOLUNTARIOS if x["id"] == id), None)
    if not v:
        flash("Voluntário não encontrado.", "error")
        return redirect(url_for("voluntarios"))

    # se for POST, atualiza o voluntário
    if request.method == "POST":
        v.update({
            "nome": request.form.get("nome"),
            "rfid": request.form.get("rfid") or None,
            "ativo": True if request.form.get("ativo") == "on" else False,
        })
        flash("Voluntário atualizado.", "success")
        return redirect(url_for("voluntarios"))

    # se for GET, abre o formulário com dados do voluntário
    return render_template("voluntario_form.html", voluntario=v)

@app.route("/voluntarios/<int:id>/excluir")
@login_required
def voluntarios_excluir(id):
    global VOLUNTARIOS
    # remove pelo id
    VOLUNTARIOS = [x for x in VOLUNTARIOS if x["id"] != id]
    flash("Voluntário excluído.", "success")
    return redirect(url_for("voluntarios"))

# --- Mock de domínio ---
VOLUNTARIOS = [
    {"id": 1, "nome": "Ana Souza", "rfid": "04A1B2C3D4", "ativo": True},
    {"id": 2, "nome": "Carlos Lima", "rfid": None, "ativo": True},
]
REGISTROS_PONTO = [
    {"id": 10, "nome": "Ana Souza", "tipo": "Entrada", "origem": "ESP", "horario": "08:02"},
    {"id": 11, "nome": "Carlos Lima", "tipo": "Entrada", "origem": "WEB", "horario": "08:10"},
]
IOT_CFG = {"host": "test.mosquitto.org", "port": 1883}
MQTT_STATUS = "offline"


# --- Middleware: protege tudo que não for login/register/static ---
@login_manager.unauthorized_handler
def unauthorized():
    flash("Faça login para continuar.", "error")
    return redirect(url_for("login"))

@app.before_request
def require_login_for_everything():
    public_endpoints = {"login", "register", "static"}
    if request.endpoint is None:
        return
    if request.endpoint.split(".")[0] not in public_endpoints and not current_user.is_authenticated:
        return redirect(url_for("login"))


# --- Rotas públicas ---
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not name or not email or not password:
            flash("Preencha todos os campos.", "error")
            return render_template("register.html")

        if _find_registered_by_email(email):
            flash("Já existe uma conta com este e-mail.", "error")
            return render_template("register.html")

        new_id = max([int(u.id) for u in USERS.values()] + [100]) + 1
        item = {
            "id": new_id,
            "name": name,
            "email": email,
            "role": "voluntario",
            "password_hash": generate_password_hash(password),
            "created_at": datetime.now().isoformat()
        }

        REGISTERED.append(item)
        _save_registered(REGISTERED)
        USERS[str(new_id)] = User(new_id, name, email, "voluntario", item["password_hash"])
        login_user(USERS[str(new_id)])
        flash("Conta criada e login efetuado!", "success")
        return redirect(url_for("dashboard"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        reg = _find_registered_by_email(email)
        if not reg:
            flash("Conta não encontrada. Cadastre-se primeiro.", "error")
            return render_template("login.html")

        if not check_password_hash(reg.get("password_hash", ""), password):
            flash("Credenciais inválidas.", "error")
            return render_template("login.html")

        u = USERS.get(str(reg["id"]))
        login_user(u)
        flash("Login efetuado com sucesso!", "success")
        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Sessão encerrada.", "success")
    return redirect(url_for("login"))


# --- Rotas autenticadas ---
@app.route("/")
@login_required
def dashboard():
    kpis = {
        "voluntarios_ativos": sum(1 for v in VOLUNTARIOS if v["ativo"]),
        "presencas_hoje": len(REGISTROS_PONTO),
        "dispositivos_online": 0
    }
    return render_template("dashboard.html", kpis=kpis)


@app.route("/usuarios")
@login_required
def usuarios():
    if not current_user.is_admin:
        flash("Apenas administradores podem ver usuários.", "error")
        return redirect(url_for("dashboard"))
    usuarios = [{"id": u.id, "nome": u.name, "email": u.email, "papel": u.role} for u in USERS.values()]
    return render_template("usuarios_list.html", usuarios=usuarios)


@app.route("/usuarios/novo", methods=["GET", "POST"])
@login_required
def usuarios_novo():
    if not current_user.is_admin:
        flash("Apenas administradores podem criar usuários.", "error")
        return redirect(url_for("usuarios"))

    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        papel = request.form.get("papel", "voluntario")
        senha = request.form.get("senha", "")

        if not nome or not email:
            flash("Preencha nome e e-mail.", "error")
            return render_template("usuario_form.html", usuario=None)

        for it in REGISTERED:
            if it.get("email", "").lower() == email:
                flash("Já existe um usuário com este e-mail.", "error")
                return render_template("usuario_form.html", usuario=None)

        new_id = max([int(u.id) for u in USERS.values()] + [100]) + 1
        item = {
            "id": new_id,
            "name": nome,
            "email": email,
            "role": papel,
            "password_hash": generate_password_hash(senha) if senha else None,
            "created_at": datetime.now().isoformat()
        }

        REGISTERED.append(item)
        _save_registered(REGISTERED)
        USERS[str(new_id)] = User(new_id, nome, email, papel, item["password_hash"])
        flash("Usuário criado.", "success")
        return redirect(url_for("usuarios"))

    return render_template("usuario_form.html", usuario=None)


@app.route("/usuarios/<int:id>/editar", methods=["GET", "POST"])
@login_required
def usuarios_editar(id):
    if not current_user.is_admin:
        flash("Apenas administradores podem editar usuários.", "error")
        return redirect(url_for("usuarios"))

    u = USERS.get(str(id))
    usuario = {"id": u.id, "nome": u.name, "email": u.email, "papel": u.role} if u else None
    if not usuario:
        flash("Usuário não encontrado.", "error")
        return redirect(url_for("usuarios"))

    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        papel = request.form.get("papel", "voluntario")
        senha = request.form.get("senha", "")

        u.name, u.email, u.role = nome, email, papel
        if senha:
            u.password_hash = generate_password_hash(senha)

        for it in REGISTERED:
            if it.get("id") == int(u.id):
                it["name"] = nome
                it["email"] = email
                it["role"] = papel
                if senha:
                    it["password_hash"] = u.password_hash
                break

        _save_registered(REGISTERED)
        flash("Usuário atualizado.", "success")
        return redirect(url_for("usuarios"))

    return render_template("usuario_form.html", usuario=usuario)


# --- Outras rotas autenticadas ---
@app.route("/ponto")
@login_required
def ponto():
    return render_template("ponto.html", registros=REGISTROS_PONTO)

@app.route("/ponto/registrar/<tipo>")
@login_required
def ponto_registrar(tipo):
    REGISTROS_PONTO.append({
        "id": random.randint(100, 999),
        "nome": current_user.name,
        "tipo": "Entrada" if tipo.lower() == "entrada" else "Saída",
        "origem": "WEB",
        "horario": datetime.now().strftime("%H:%M")
    })
    flash("Registro adicionado.", "success")
    return redirect(url_for("ponto"))

@app.route("/voluntarios")
@login_required
def voluntarios():
    return render_template("voluntarios_list.html", voluntarios=VOLUNTARIOS)

@app.route("/voluntarios/novo", methods=["GET", "POST"])
@login_required
def voluntarios_novo():
    if request.method == "POST":
        novo = {
            "id": max([v["id"] for v in VOLUNTARIOS] + [0]) + 1,
            "nome": request.form.get("nome"),
            "rfid": request.form.get("rfid") or None,
            "ativo": True if request.form.get("ativo") == "on" else False,
        }
        VOLUNTARIOS.append(novo)
        flash("Voluntário criado.", "success")
        return redirect(url_for("voluntarios"))
    return render_template("voluntario_form.html", voluntario=None)

@app.route("/iot")
@login_required
def iot():
    return render_template("iot.html", cfg=IOT_CFG, mqtt_status=MQTT_STATUS)

@app.route("/relatorios")
@login_required
def relatorios():
    linhas = [{"nome": "Ana Souza", "horas": "04:00"}, {"nome": "Carlos Lima", "horas": "03:30"}]
    return render_template("relatorios.html", linhas=linhas)

@app.route("/suporte")
@login_required
def suporte():
    return render_template("suporte.html", ava_url="https://www.pucpr.br/ava/")


# --- Execução ---
if __name__ == "__main__":
    app.run(debug=True)
